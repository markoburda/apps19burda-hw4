package ua.edu.ucu.tries;

public class RWayTrie implements Trie {

    @Override
    public void add(Tuple t) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean contains(String word) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean delete(String word) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Iterable<String> words() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Iterable<String> wordsWithPrefix(String s) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int size() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

}
